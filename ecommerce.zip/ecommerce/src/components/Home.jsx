import React from 'react'
import './Home.css'
const Home = () => {
    return (
        <div className='homepar'>
            <h2>
                Exclusive Products
            </h2>

        </div>
    )
}

export default Home
